#boolean
print("Hello World")
print(True)
#basestring
name="Preston"
print(name)
#integer
a=13
print(a)
#float
b=13.5
print(b)